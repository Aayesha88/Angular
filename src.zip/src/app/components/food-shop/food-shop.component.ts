import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-shop',
  templateUrl: './food-shop.component.html',
  styleUrls: ['./food-shop.component.css']
})
export class FoodShopComponent implements OnInit {
  foodshopcomponent = "Entered in foodshop component created";


  constructor() { }

  ngOnInit() {
  } 

}
