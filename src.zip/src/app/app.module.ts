import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { FoodShopComponent } from './components/food-shop/food-shop.component';
import { FoodMenuComponent } from './components/food-menu/food-menu.component';
import { HomeComponent } from './components/home/home.component';
import { OrderFoodComponent } from './components/order-food/order-food.component';
import { LoginComponent } from './components/login/login.component';
import { CreateaccountComponent } from './components/createaccount/createaccount.component';





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    FoodShopComponent,
    FoodMenuComponent,
    HomeComponent,
    OrderFoodComponent,
    LoginComponent,
    CreateaccountComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
