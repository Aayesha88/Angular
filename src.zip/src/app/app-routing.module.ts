import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FoodShopComponent } from 'src/app/components/food-shop/food-shop.component';
import { HomeComponent } from 'src/app/components/home/home.component';
import { FoodMenuComponent } from 'src/app/components/food-menu/food-menu.component';
import { OrderFoodComponent } from 'src/app/components/order-food/order-food.component';
import { LoginComponent } from 'src/app/components/login/login.component';
import { CreateaccountComponent } from 'src/app/components/createaccount/createaccount.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path: 'food-shop' , component: FoodShopComponent},
  {path: 'home' , component: HomeComponent},
  {path: 'food-menu' , component: FoodMenuComponent},
  {path: 'order-food' , component: OrderFoodComponent},
  {path: 'login' , component: LoginComponent},
  {path: 'createaccount' , component: CreateaccountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
